package com.example.my1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    LinearLayout baseLayout;
    Button button1;
    boolean triggerFlagColorRed = false;
    boolean triggerFlagColorGreen = false;
    boolean triggerFlagColorBlue = false;
    boolean triggerFlagsubRotate = false;
    boolean triggerFlagsubSize = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("배경색 바꾸기");
        baseLayout = (LinearLayout) findViewById(R.id.baseLayout);
        button1 = (Button) findViewById(R.id.button1);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater mInflater = getMenuInflater();
        mInflater.inflate(R.menu.menu1,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        switch (item.getItemId()) {
            case R.id.itemRed:
                if(triggerFlagColorRed == true) {
                    baseLayout.setBackgroundColor(Color.RED);
                    triggerFlagColorRed = false;
                }
                else if(triggerFlagColorRed == false) {
                    triggerFlagColorRed = true;
                    triggerFlagColorGreen = false;
                    triggerFlagColorBlue = false;
                }
                return true;

            case R.id.itemGreen:
                if(triggerFlagColorGreen == true) {
                    baseLayout.setBackgroundColor(Color.RED);
                    triggerFlagColorGreen = false;
                }
                else if(triggerFlagColorGreen == false) {
                    triggerFlagColorRed = false;
                    triggerFlagColorGreen = true;
                    triggerFlagColorBlue = false;
                }
                return true;
            case R.id.itemBlue:
                if(triggerFlagColorBlue == true) {
                    baseLayout.setBackgroundColor(Color.RED);
                    triggerFlagColorBlue = false;
                }
                else if(triggerFlagColorBlue == false) {
                    triggerFlagColorRed = false;
                    triggerFlagColorGreen = false;
                    triggerFlagColorBlue = true;
                }
                return true;
            case R.id.subRotate:
                if(triggerFlagsubRotate == true) {
                    button1.setRotation(0);
                    triggerFlagsubRotate = false;
                }
                else if(triggerFlagsubRotate == false) {
                    button1.setRotation(45);
                    triggerFlagsubRotate = true;
                }
                return true;

            case R.id.subSize:
                if(triggerFlagsubSize == true) {
                    button1.setScaleX(1);
                    triggerFlagsubSize = false;
                }
                else if(triggerFlagsubSize == false) {
                    button1.setScaleX(2);
                    triggerFlagsubSize = true;
                }
                return true;
            case R.id.itemReset:
                button1.setRotation(0);
                button1.setScaleX(1);
                return true;

        }
        return false;

    }
}