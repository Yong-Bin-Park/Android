package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String[] items = {"CSI.뉴욕","CSI.라스베가스","CSI.마이애미","Friends","Fringe","Lost"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_dropdown_item_1line,items);

        AutoCompleteTextView auto =
                (AutoCompleteTextView) findViewById(R.id.autoTextView1);
        auto.setAdapter(adapter);
        MultiAutoCompleteTextView multiAuto =
                (MultiAutoCompleteTextView) findViewById(R.id.multiAutoTextView1);
        MultiAutoCompleteTextView.CommaTokenizer token =
                new MultiAutoCompleteTextView.CommaTokenizer();
        multiAuto.setTokenizer(token);
        multiAuto.setAdapter(adapter);
    }
}