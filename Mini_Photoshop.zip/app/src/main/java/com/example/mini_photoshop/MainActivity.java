package com.example.mini_photoshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.EmbossMaskFilter;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    ImageButton ibZoomin, ibZoomout, ibRotate, ibBright, ibDark,ibBlur,ibEmboss;
    MyGraphicView graphicView;
    static float scaleX = 1, scaleY = 1;
    static float angle = 0;
    static float satur = 1;
    static boolean blur = false, emboss = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("미니 포토샵");

        LinearLayout pictureLayout = (LinearLayout)findViewById(R.id.pictureLayout);
        graphicView = (MyGraphicView) new MyGraphicView(this);
        pictureLayout.addView(graphicView);

        clickIcons();

    }

    private void clickIcons() {
        ibZoomin = (ImageButton)findViewById(R.id.ibZoomin);
        ibZoomin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scaleX += 0.2f;
                scaleY += 0.2f;
                graphicView.invalidate();
            }
        });

        ibZoomout = (ImageButton)findViewById(R.id.ibZoomout);
        ibZoomout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scaleX -= 0.2f;
                scaleY -= 0.2f;
                graphicView.invalidate();
            }
        });

        ibRotate = (ImageButton)findViewById(R.id.ibRotate);
        ibRotate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                angle += 20;
                graphicView.invalidate();
            }
        });

        ibBright = (ImageButton)findViewById(R.id.ibBright);
        ibBright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                satur = satur +0.2f;
                graphicView.invalidate();
            }
        });

        ibDark = (ImageButton)findViewById(R.id.ibDark);
        ibDark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                satur = satur -0.2f;
                graphicView.invalidate();
            }
        });

        ibBlur = (ImageButton)findViewById(R.id.ibBlur);
        ibBlur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(blur == true)
                    blur = false;
                else
                    blur = true;
                graphicView.invalidate();
            }
        });

        ibEmboss = (ImageButton)findViewById(R.id.ibEmboss);
        ibEmboss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(emboss ==true)
                    emboss = false;
                else
                    emboss = true;
                graphicView.invalidate();
            }
        });
    }

    private static class MyGraphicView extends View {


        public MyGraphicView(Context context) {
            super(context);
        }
        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            int cenX = this.getWidth() /2;
            int cenY = this.getHeight() /2;
            canvas.scale(scaleX, scaleY, cenX, cenY);
            canvas.rotate(angle,cenX,cenY);
            Paint paint = new Paint();
            float[] array = {
                    satur, 0, 0, 0, 0,
                    0, satur, 0, 0, 0,
                    0, 0, satur, 0, 0,
                    0, 0, 0, 1, 0
            };
            ColorMatrix cm = new ColorMatrix(array);


            paint.setColorFilter(new ColorMatrixColorFilter(cm));
            if(blur==true)
                paint.setMaskFilter(new BlurMaskFilter(30,BlurMaskFilter.Blur.NORMAL));
            if(emboss==true)
                paint.setMaskFilter(new EmbossMaskFilter(new float[]{3,3,3}, 0.5f, 5, 10));

            Bitmap picture = BitmapFactory.decodeResource(getResources(),R.drawable.star);

            int picX = (this.getWidth() - picture.getWidth()) / 2;
            int picY = (this.getHeight() - picture.getHeight()) / 2;
            canvas.drawBitmap(picture, picX, picY, paint);

            picture.recycle();
        }
    }
}