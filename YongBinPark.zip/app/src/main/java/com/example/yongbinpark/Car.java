package com.example.yongbinpark;

public class Car {
    String color,name;
    int speed =0;

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
    void upSpeed(int value) {
        if(speed + value >= 200)
            speed = 200;
        else
            speed =speed +value;
    }
    void downSpeed(int value) {
        if(speed - value <= 0)
            speed = 0;
        else
            speed =speed -value;
    }
}
