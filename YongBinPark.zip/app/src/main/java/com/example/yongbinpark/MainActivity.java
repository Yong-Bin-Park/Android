package com.example.yongbinpark;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity {
    Button button1,button2,button3;
    int cntOnClick = 0;
    TextView tv1,tv2,tv3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        tv1.setText("Hello!");
        tv1.setTextColor(Color.BLUE);
        tv2.setTextSize(10);
        tv3.setText("abcdefghijkl가나다라마바사아자차카타파하");
        tv3.setSingleLine();

        Car myCar1 = new Car();
        myCar1.setName("YongBinCar");
        myCar1.setColor("Red and blue");
        myCar1.setSpeed(120);
        button1 = (Button) findViewById(R.id.button1);
        button1.setOnClickListener(new View.OnClickListener() {
            int chkClicks = 0;

            @Override
            public void onClick(View view) {
                chkClicks = cntOnClick % 4;

                Toast.makeText(getApplicationContext(),"나의 차 이름은"+myCar1.getName(),Toast.LENGTH_SHORT).show();
                cntOnClick++;

            }
        });

        button2 = (Button) findViewById(R.id.button2);

        button2.setOnClickListener(new View.OnClickListener() {
            int chkClicks = 0;

            @Override
            public void onClick(View view) {
                chkClicks = cntOnClick % 4;
               Toast.makeText(getApplicationContext(),"색깔은 "+myCar1.getColor(),Toast.LENGTH_SHORT).show();
                cntOnClick++;

            }
        });




    }
}