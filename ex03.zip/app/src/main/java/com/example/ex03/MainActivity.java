package com.example.ex03;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import static java.lang.Thread.sleep;

public class MainActivity extends AppCompatActivity {
    Button button1,button2,button3;
    int cntOnClick = 0;
    String[] textOnClick ={"시작","눌렀습니다!","이미 눌렀습니다!","충분히 눌렀습니다!"};
    String textOnClick1 = "안녕하세요 과제입니다.";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1 = (Button) findViewById(R.id.button1);

        button1.setOnClickListener(new View.OnClickListener() {
            int chkClicks = 0;

            @Override
            public void onClick(View view) {
                chkClicks = cntOnClick % 4;
                if (chkClicks == 0) {
                    Toast.makeText(getApplicationContext(),
                            textOnClick[0]
                            , Toast.LENGTH_SHORT).show();
                }
                if (chkClicks == 1) {
                    Toast.makeText(getApplicationContext(),
                            textOnClick[1]
                            , Toast.LENGTH_SHORT).show();
                }
                if (chkClicks == 2) {
                    Toast.makeText(getApplicationContext(),
                            textOnClick[2]
                            , Toast.LENGTH_SHORT).show();
                }
                if (chkClicks == 3) {
                    Toast.makeText(getApplicationContext(),
                            textOnClick[3]
                            , Toast.LENGTH_SHORT).show();

                }
                cntOnClick++;

            }
        });
        button2 = (Button) findViewById(R.id.button2);

        button2.setOnClickListener(new View.OnClickListener() {
            int chkClicks = 0;

            @Override
            public void onClick(View view) {
                chkClicks = cntOnClick % 4;
                for(int cntLoop=3;cntLoop>0;cntLoop--) {
                    Toast.makeText(getApplicationContext(), "과제종료까지" + cntLoop * 2 + "초", Toast.LENGTH_SHORT).show();

                    try {
                        sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                }
                cntOnClick++;

            }
        });
        button3 = (Button) findViewById(R.id.button3);

        button3.setOnClickListener(new View.OnClickListener() {
            int chkClicks = 0;

            @Override
            public void onClick(View view) {
                chkClicks = cntOnClick % 4;
                Toast.makeText(getApplicationContext(),textOnClick1,Toast.LENGTH_SHORT).show();
                cntOnClick++;

            }
        });
    }
}
