package com.example.memory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn1Write, btn2Read;

        btn1Write = (Button) findViewById(R.id.btn1Write);
        btn2Read = (Button) findViewById(R.id.btn2Rdad);

        btn1Write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    FileOutputStream outF5
                            = openFileOutput("file.txt", Context.MODE_PRIVATE);
                    String str= "안드로이드 학습";
                    outF5.write(str.getBytes());
                    outF5.close();
                    Toast.makeText(getApplicationContext(),"파일생성완료",Toast.LENGTH_SHORT).show();
                }catch (IOException e) {}
            }
        });

        btn2Read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    FileInputStream inF5 = openFileInput("file.txt");
                    byte[] text = new byte[50];
                    inF5.read(text);
                    String txtStr = new String(text);
                    Toast.makeText(getApplicationContext(),txtStr,Toast.LENGTH_SHORT).show();
                    inF5.close();
                }catch (IOException e) {
                    Toast.makeText(getApplicationContext(),"No File",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}